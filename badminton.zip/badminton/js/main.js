//=============== IF .home-btn IS CLICKED DO THIS==================//


$(function () {
    //=============== IF .start-btn IS CLICKED DO THIS==================//

    $(".startt").click(function () {

        console.log("start button is clicked");
        showpopup();

    });

    $(".string").click(function () {

        console.log("stringinfo is clicked");
        openpopinfo();

    });
    //=============== IF .close-btn IS CLICKED DO THIS==================//

    $(".close").click(function () {

        console.log("close button is clicked");
        closepopup();
        closepopinfo();

    });
    //=============== IF .fw-btn IS CLICKED DO THIS==================//
    $(".fw").click(function () {

        console.log("fw button is clicked");
        closepopup();
        showscene1();

    });
    //=============== IF .hits-btn IS CLICKED DO THIS==================//
    $(".hits").click(function () {

        console.log("hits button is clicked");
        closepopup();
        showscene2();

    });
    //=============== IF .strings-btn IS CLICKED DO THIS==================//
    $(".strings").click(function () {

        console.log("strings button is clicked");
        closepopup();
        showscene3();

    });

    $(".string").click(function () {

        console.log("string button is clicked");
        openpopinfo();

    });
    //=============== IF .rackets-btn IS CLICKED DO THIS==================//
    $(".rackets").click(function () {

        console.log("rackets button is clicked");
        closepopup();
        showscene4();

    });

    //=============== IF .prevbtn1-btn IS CLICKED DO THIS==================//
    $(".prevbtn1").click(function () {

        console.log("prevbtn1 button is clicked");
        showscene0();

    });

    //=============== IF .nextbtn1-btn IS CLICKED DO THIS==================//
    $(".nextbtn1").click(function () {

        console.log("nextbtn1 button is clicked");
        showscene2();

    });

    //=============== IF .nextbtn2-btn IS CLICKED DO THIS==================//
    $(".nextbtn2").click(function () {

        console.log("nextbtn2 button is clicked");
        showscene3();

    });





    //=============== IF .prevbtn2-btn IS CLICKED DO THIS==================//
    $(".prevbtn2").click(function () {

        console.log("nextbtn2 button is clicked");
        showscene1();

    });

    //=============== IF .prevbtn3-btn IS CLICKED DO THIS==================//
    $(".prevbtn3").click(function () {

        console.log("prevbtn3 button is clicked");
        showscene2();

    });
    //=============== IF .nextbtn3-btn IS CLICKED DO THIS==================//
    $(".nextbtn3").click(function () {

        console.log("nextbtn3 button is clicked");
        showscene4();

    });
    //=============== IF .nextbtn3-btn IS CLICKED DO THIS==================//
    $(".nextbtn4").click(function () {

        console.log("nextbtn4 button is clicked");
        showscene0();

    });
    //=============== IF .nextbtn3-btn IS CLICKED DO THIS==================//
    $(".prevbtn4").click(function () {

        console.log("prevbtn4 button is clicked");
        showscene3();

    });
    //=============== IF .nextbtn3-btn IS CLICKED DO THIS==================//
    $(".menubtn").click(function () {

        console.log("menubtn button is clicked");
        showscene0();
        showpopup();

    });
    //=============== IF .nextbtn3-btn IS CLICKED DO THIS==================//
    $(".homebtn").click(function () {

        console.log("homebtn button is clicked");
        showscene0();

    });

    $(".btnbasic").click(function () {
        popup("Basic", "For basic footwork, you have to take care of 6 corners, defensive footwork, rear court footwork and front court footwork. It covers most of the areas of the court and with the right techniques, you would be able to move around the court efficiently.");
        basic();
        closeorange();
        closeOffence()
        
    });

    $(".btndef").click(function () {
        popup("Defence", "In badminton doubles,two players will be defending half court on each side, this way both players cover a shorter distance compared to singles players.");
        closebasic();
        orangeBois();
        closeOffence();
    });

    $(".btnoff").click(function () {
        popup("Offence", "For doubles, one player will be on the rear court, while the other on the front court, the player on the rear court will smash or make drop shots to attack the opposing team, the player on the front court will perform net kill shots or net play with the opposing team. However, the rear court player may get tired overtime after doing several smashes, the players will rotate.");
        closebasic();
        closeorange();
        offenceBlue();
    });

    $(".str1").click(function () {
        popinfo("BG66", "This ultra-thin gauge string offers the ultimate in repulsion power and a clear hitting sound.<br><br><b>Gauge:</b> 0.66 mm<br><b>Length:</b> 10m(33 ft)<br><b>Core:</b> High Polymer Nylon Multifilament<br><b>Outer:</b>Special Braided High Polymer Nylon Fiber<br><b>Made in:</b> Japan");
    });

    $(".str2").click(function () {
        popinfo("BG66 Ultimax", "The BG66UM has a 0.65mm thin gauge and the perfect balance of maximum speed, control, and durability, making it the best choice for the world's top players.<br><b>Gauge:</b> 0.65 mm<br><b>Length:</b> 10 m (33 ft), 200 m (656 ft)<br><b>Core:</b> High-Intensity Nylon Multifilament<br><b>Outer:</b>Special Braided High Polymer Nylon Fiber<br><b>Made in:</b> Japan");
    });

    $(".str3").click(function () {
        popinfo("BG66", "This ultra-thin gauge string offers the ultimate in repulsion power and a clear hitting sound.<br><br><b>Gauge:</b> 0.66 mm<br><b>Length:</b> 10m(33 ft)<br><b>Core:</b> High Polymer Nylon Multifilament<br><b>Outer:</b>Special Braided High Polymer Nylon Fiber<br><b>Made in:</b> Japan");
    });

    $(".str4").click(function () {
        popinfo("BG65", "The 0.70mm specially braided fibre increases string abrasion durability. The BG65's all-round performance makes it the choice of the world's top players.<br><b>Gauge:</b> 0.70 mm<br><b>Length:</b> 10m(33 ft), 200 m (656 ft), 500 m (1,640ft)<br><b>Core:</b> High Polymer Nylon Multifilament<br><b>Outer:</b>Special Braided High Polymer Nylon Fiber<br><b>Made in:</b> Japan");
    });

    $(".str5").click(function () {
        popinfo("NANOGY 95", "Compound Cup-Stack Carbon Nanotube achieves great repulsion combined with high durability. Suited for players looking for speed and durability.<br><b>Gauge:</b> 0.69 mm<br><b>Length:</b> 10m(33 ft), 200 m (656 ft)<br><b>Core:</b> High Polymer Nylon Multifilament<br><b>Outer:</b>Special Braided High Polymer Nylon Fiber<br><b>Made in:</b> Japan");
    });

    $(".str6").click(function () {
        popinfo("BG65 TITANIUM", "The compound titanium hybrid coating provides a sharp but comfortable feel at impact. Designed for hard hitters.<br><br><b>Gauge:</b> 0.70 mm<br><b>Length:</b> 10m(33 ft), 200 m (656 ft)<br><b>Core:</b> High Polymer Nylon Multifilament<br><b>Outer:</b>Special Braided High Polymer Nylon Fiber<br><b>Made in:</b> Japan");
    });

    $(".str7").click(function () {
        popinfo("AEROBITE BOOST", "A hybrid multifilament string engineered for maximum control without sacrificing repulsion. The vertical strings are made of Vectran(tm), a super fiber more than twice as powerful as nylon.<br><b>Gauge:</b> mains - 0.72 mm; crosses - 0.61 mm<br><b>Length:</b> mains - 5.5 m (18 ft); crosses - 5 m (16 ft)<br><b>Core:</b> High Polymer Nylon Multifilament, Super Fiber: Vectran (mains only)<br><b>Outer:</b>High Polymer Braided Nylon Fiber, Oval-Shaped (mains only)<br><b>Made in:</b> Japan");
    });

    $(".str8").click(function () {
        popinfo("AEROBITE", "Yonex’s first ever hybrid string combo. The new AEROBITE applies heavy spin for decisive cut smashes or a solid touch for hairpins that drop straight down.<br><b>Gauge:</b> mains - 0.67 mm; crosses - 0.61 mm<br><b>Length:</b> mains - 5.5 m (18 ft); crosses - 5 m (16 ft); mains - 105 m (344 ft); crosses - 95 m (311 ft)<br><b>Core:</b> High Polymer Nylon Multifilament<br><b>Outer:</b>High Polymer Braided Nylon Fiber<br><b>Made in:</b> Japan");
    });

    $(".str9").click(function () {
        popinfo("NANOGY 99", "YONEX original rough braided fibre and a special nylon coating provide maximum bite on the shuttle for enhanced hairpin net shots and cuts<br><b>Gauge:</b> 0.69mm<br><b>Length:</b> 10 m (33 ft)<br><b>Core:</b> High Polymer Nylon Multifilament<br><b>Outer:</b>High Polymer Nylon Rough Braided Fiber<br><b>Made in:</b> Japan");
    });


    $(".next").click(function () {
        // test("Get into Position and Adopt the Forehand Grip, Raise your Racket Arm and Non-Racket Arm");
        next();


    });

    $(".prev").click(function () {
        // test("Get into Position and Adopt the Forehand Grip, Raise your Racket Arm and Non-Racket Arm");
        prev();


    });

    $(".heavy").mouseenter(function () {
        console.log("hoverworks");
        racketexplain("Head Heavy Rackets", "Head Heavy racquets are also called power racquets. More weight is distributed at the top of the racket head, giving you more momentum in your swing. This produces more powerful shots. Badminton Clears are mostly effortless; Smashes are often DEADLY. <br><br> Go for head heavy rackets only if you are a big fan of smashing, play singles in badminton or attack very often from the rear court in doubles");
    });

    $(".light").mouseenter(function () {
        console.log("hoverworks");
        racketexplain("Head Light Rackets", "Head Light badminton racquets are good for control players, or players who like to have a SPEED advantage in their games.ead Light racquets are normally more popular in doubles. You’ll be able to control better at the net area. If you engage in fast rallies with a lot of drives, the head light racquet could also give you the advantage you need. ");
    });

    $(".balance").mouseenter(function () {
        console.log("hoverworks");
        racketexplain("All Rounder Rackets", "This type of badminton racquets are very ‘user friendly’; whether you are a beginner or advanced player. Perfect for “all-rounders” because the weight is evenly distributed within the badminton racquet, this makes it easy for BOTH generating power as well as superb racquet handling. Even balance racquets are very popular among doubles players. If your game consists of an even combination of clears, drops and smashes, an even balanced racquet can help you deliver the best in your games!");
    });


    $(".racket").mouseleave(function () {
        console.log("left the premises");
        resetback("Hello!", "Hover to any of the rackets above to see the description of each types of racket.")
    })
    /////////////////////////////////////////////////////////////
    $(".infoshot").html("<h3>Jump Smash</h3><br>1. Get into Position and Adopt the Forehand Grip.<br>2. Raise your Racket Arm and Non-Racket Arm.<br>3. Jump into the Air.<br>4. Hit the Shuttle at the Highest Point Possible.<br>5. Follow Through, Land, and Maintain Body Balance.");


    startOranges();
    closeOffence();
}); //End of document ready function


function racketexplain(name, desc) {
    $(".racketname").text(name);
    $(".racketdes").html(desc);
}

function resetback(name, desc) {
    $(".racketname").text(name);
    $(".racketdes").html(desc);
}


var counter = 1;

function next() {
    counter++;

    if (counter == 1) {
        $(".infoshot").html("<h3>Jump Smash</h3>1. Get into Position and Adopt the Forehand Grip.<br>2. Raise your Racket Arm and Non-Racket Arm.<br>3. Jump into the Air.<br>4. Hit the Shuttle at the Highest Point Possible.<br>5. Follow Through, Land, and Maintain Body Balance.");
    } else if (counter == 2) {
        $(".infoshot").html("<h3>High Serve</h3>1.Hold the head of the shuttlecock with its head facing downwards so that the shuttlecock will drop straight down.<br>2.Stand sideways (the side of your body facing the net) and relax your racquet arm (arm that is holding the racquet). 3.Let go of the shuttlecock and swing your racquet arm upwards.<br>4.Flick your wrist upwards, so that the shuttlecock will fly high");
    } else if (counter == 3) {
        $(".infoshot").html("<h3>Overhead Clearshot</h3>1. Move into position and get behind the shuttle. Adopt the Forehand Grip.<br>2. Raise your Racket Arm and Non-Racket Arm.<br>3. Your body should face sideways with your feet pointing slightly sideways.<br>4. Commence your Forehand Stroke. Stretch your Racket Arm to as far back as possible. Stretch out your Non-Racket Arm. Inhale. Then Exhale as you swing your racket forward.");
    } else if (counter == 4) {
        $(".infoshot").html("<h3>Net shot</h3>1. Lunge forward to the net with your Racket Foot.<br>2. As you’re moving forward, raise your racket arm to around shoulder height. Ideally, this is the height where you’re going to make contact with the shuttle.<br>3. Avoid holding your racket too tightly.<br>4. Tilt your head slightly towards the shoulder of your racket arm. This enables better control of the racket.<br>5. Make contact with the shuttle. Slice the shuttle to achieve the tumbling effect.");
    } else if (counter == 5) {
        $(".infoshot").html("<h3>Lifting</h3>1. Adopt the Backhand Grip. Don’t hold your racket too tightly.<br>2. Lunge forward with your Racket Leg. Make sure you position your racket in front of you.<br>3. Take the shuttle when it’s in front of you. Avoid taking it from the side of your body.<br>4. As you make contact with the shuttle, Bend your knees, Bend your body, and Contract your Abs.<br>5. Follow Through with your swing.");
    }
    $(".shots").attr("src", "images/shots" + counter + ".png");

    if (counter == 5) {
        counter = 0;
    }
}


function startOranges(){
    var defend = gsap.timeline();
    gsap.set(".orange1", {display:"none"});   
    gsap.set(".orange2", {display:"none"});
    defend.to(".orange1", {bottom: "200px", left: "100px", duration: 1,repeat:-1, yoyo:true, ease:"linear"},0);
    defend.to(".orange2",{bottom: "0px",left: "250px",duration: 1, repeat:-1, yoyo:true, ease:"linear"},0);
}

function orangeBois(){
    gsap.set(".orange1", {display:"block"});
    gsap.set(".orange2", {display:"block"});

}

function closeorange(){
    gsap.set(".orange1", {display:"none"});   
    gsap.set(".orange2", {display:"none"});
}

function closebasic() {
    gsap.set(".bluecircle", {
        display: "none"
    });
    gsap.to(".bluecircle", {
        opacity: 0,
    });
    gsap.set(".circle", {display:"none"});

    gsap.to(".circle", {
        opacity: 0,
    });
}

function offenceBlue(){
    gsap.set(".offence-container", {
        display: "block"
    });
    gsap.to(".offence-container", {rotate:"180deg", repeat: -1, duration:1,repeatDelay:2, ease:"ease.linear.none"});
    // gsap.to(".offence-container", {height:"240px", repeat: -1, duration:1,repeatDelay:2,yoyo:true, ease:"ease.linear.none", delay: 0.5});
}

function closeOffence(){
    gsap.set(".offence-container", {
        display: "none"
    });
}

var basicc = gsap.timeline();


function basic() {
    gsap.set(".circle", {display: "block"});
    gsap.to(".circle", {opacity: 1});
    gsap.set(".bluecircle", {
        display: "block"
    });
    gsap.to(".bluecircle", {
        opacity: 1,
        duration: 0.8
    });

    basicc.to(".circle", {
        left: "75px",
        bottom: "240px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "152px",
        left: "200px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "239px",
        left: "325px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "152px",
        left: "200px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "120px",
        left: "325px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "120px",
        left: "325px",
        duration: 1,
        
    });
    basicc.to(".circle", {
        bottom: "152px",
        left: "200px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "0px",
        left: "325px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "152px",
        left: "200px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "0px",
        left: "75px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "152px",
        left: "200px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "119px",
        left: "75px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "152px",
        left: "200px",
        duration: 1,
        delay: 1
    });
    basicc.to(".circle", {
        bottom: "239px",
        left: "75px",
        duration: 1,
        delay: 1
    });
}

function prev() {
    if (counter == 1) {
        counter = 5;
    }
    counter--;

    if (counter == 1) {
        $(".infoshot").html("<h3>Jump Smash</h3>1. Get into Position and Adopt the Forehand Grip.<br>2. Raise your Racket Arm and Non-Racket Arm.<br>3. Jump into the Air.<br>4. Hit the Shuttle at the Highest Point Possible.<br>5. Follow Through, Land, and Maintain Body Balance.");
    } else if (counter == 2) {
        $(".infoshot").html("<h3>High Serve</h3>1.Hold the head of the shuttlecock with its head facing downwards so that the shuttlecock will drop straight down.<br>2.Stand sideways (the side of your body facing the net) and relax your racquet arm (arm that is holding the racquet). 3.Let go of the shuttlecock and swing your racquet arm upwards.<br>4.Flick your wrist upwards, so that the shuttlecock will fly high");
    } else if (counter == 3) {
        $(".infoshot").html("<h3>Overhead Clearshot</h3>1. Move into position and get behind the shuttle. Adopt the Forehand Grip.<br>2. Raise your Racket Arm and Non-Racket Arm.<br>3. Your body should face sideways with your feet pointing slightly sideways.<br>4. Commence your Forehand Stroke. Stretch your Racket Arm to as far back as possible. Stretch out your Non-Racket Arm. Inhale. Then Exhale as you swing your racket forward.");
    } else if (counter == 4) {
        $(".infoshot").html("<h3>Net shot</h3>1. Lunge forward to the net with your Racket Foot.<br>2. As you’re moving forward, raise your racket arm to around shoulder height. Ideally, this is the height where you’re going to make contact with the shuttle.<br>3. Avoid holding your racket too tightly.<br>4. Tilt your head slightly towards the shoulder of your racket arm. This enables better control of the racket.<br>5. Make contact with the shuttle. Slice the shuttle to achieve the tumbling effect.");
    } else if (counter == 5) {
        $(".infoshot").html("<h3>Lifting</h3>1. Adopt the Backhand Grip. Don’t hold your racket too tightly.<br>2. Lunge forward with your Racket Leg. Make sure you position your racket in front of you.<br>3. Take the shuttle when it’s in front of you. Avoid taking it from the side of your body.<br>4. As you make contact with the shuttle, Bend your knees, Bend your body, and Contract your Abs.<br>5. Follow Through with your swing.");
    }
    $(".shots").attr("src", "images/shots" + counter + ".png");





}

function popup(name, desc) {
    console.log(name);
    $(".infoheader").text(name);
    $(".infodes").text(desc);

}

function popinfo(name, desc) {
    console.log(name);
    $(".stringheader").text(name);
    $(".stringtext").html(desc);

}

function showpopup() {
    gsap.set(".popup", {
        display: "block"
    });
    gsap.to(".popup", {
        opacity: 1,
        duration: 0.5
    });
}

function closepopup() {
    gsap.set(".popup", {
        display: "none",
        delay: 0.5
    });
    gsap.to(".popup", {
        opacity: 0,
        duration: 0.5
    });
}

function openpopinfo() {
    gsap.set(".popinfo", {
        display: "block"
    });
    gsap.to(".popinfo", {
        opacity: 1,
        duration: 0.5
    });
}

function closepopinfo() {
    gsap.set(".popinfo", {
        display: "none",
        delay: 0.5
    });
    gsap.to(".popinfo", {
        opacity: 0,
        duration: 0.5
    });
}

function showscene0() {
    console.log("scene 0 is ready.")
    gsap.set(".scenes", {
        display: "none"
    });
    gsap.set(".scene0", {
        display: "block"
    });
}

function showscene1() {
    console.log("scene 1 is ready.")
    gsap.set(".scenes", {
        display: "none"
    });
    gsap.set(".scene1", {
        display: "block"
    });
    closeorange();
}

function showscene2() {
    console.log("scene 2 is ready.")
    gsap.set(".scenes", {
        display: "none"
    });
    gsap.set(".scene2", {
        display: "block"
    });
}

function showscene3() {
    console.log("scene 3 is ready.")
    gsap.set(".scenes", {
        display: "none"
    });
    gsap.set(".scene3", {
        display: "block"
    });
}

function showscene4() {
    console.log("scene 4 is ready.")
    gsap.set(".scenes", {
        display: "none"
    });
    gsap.set(".scene4", {
        display: "block"
    });
}